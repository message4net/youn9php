<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables`");
$num = mysql_num_rows($query);
for($flag = 0, $mainEcho = "", $i = 0;$i < $num;$i ++){
	$ID = mysql_result($query, $i, "ID");
	$system_time = mysql_result($query, $i, "system_time");
	$player1_name = mysql_result($query, $i, "player1_name");
	$player2_name = mysql_result($query, $i, "player2_name");
	$player3_name = mysql_result($query, $i, "player3_name");
	$player1_status = mysql_result($query, $i, "player1_status");
	$player2_status = mysql_result($query, $i, "player2_status");
	$player3_status = mysql_result($query, $i, "player3_status");
	$player1_time = mysql_result($query, $i, "player1_time");
	$player2_time = mysql_result($query, $i, "player2_time");
	$player3_time = mysql_result($query, $i, "player3_time");
	cleanTable($ID);
	$mainEcho .= $ID."|".$player1_name."|".$player2_name."|".$player3_name."|".$player1_status."|".$player2_status."|".$player3_status."|;";
	if($player1_name == $username || $player2_name == $username || $player3_name == $username)
	$flag = $ID;
}
echo $flag.";".$mainEcho;
?>