<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables` where `ID` = '".$_GET[tableID]."'");
$num = mysql_num_rows($query);
if($num){
	$player1_name = mysql_result($query, 0, "player1_name");
	$player2_name = mysql_result($query, 0, "player2_name");
	$player3_name = mysql_result($query, 0, "player3_name");
	if($username == $player1_name)
	{
		mysql_query("update `tables` set `player1_name` = '',`player1_status` = '',`player1_p` = '',`player2_p` = '',`player3_p` = '',`lord_p` = '',`lord` = '',`flag` = '',`player1_time` = '0',`player1_show` = '',`player2_show` = '',`player3_show` = '',`player1_status` = '',`player2_status` = '',`player3_status` = '',`player1_score` = '0',`player2_score` = '0',`player3_score` = '0' where `ID` = '".$_GET[tableID]."'");
	}
	if($username == $player2_name)
	{
		mysql_query("update `tables` set `player2_name` = '',`player2_status` = '',`player1_p` = '',`player2_p` = '',`player3_p` = '',`lord_p` = '',`lord` = '',`flag` = '',`player2_time` = '0',`player1_show` = '',`player2_show` = '',`player3_show` = '',`player1_status` = '',`player2_status` = '',`player3_status` = '',`player1_score` = '0',`player2_score` = '0',`player3_score` = '0' where `ID` = '".$_GET[tableID]."'");
	}
	if($username == $player3_name)
	{
		mysql_query("update `tables` set `player3_name` = '',`player3_status` = '',`player1_p` = '',`player2_p` = '',`player3_p` = '',`lord_p` = '',`lord` = '',`flag` = '',`player3_time` = '0',`player1_show` = '',`player2_show` = '',`player3_show` = '',`player1_status` = '',`player2_status` = '',`player3_status` = '',`player1_score` = '0',`player2_score` = '0',`player3_score` = '0' where `ID` = '".$_GET[tableID]."'");
	}
}
?>