<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables` where `ID` = '".$_GET[tableID]."'");
$num = mysql_num_rows($query);

$ID = mysql_result($query, 0, "ID");
$lord = mysql_result($query, 0, "lord");
$flag = mysql_result($query, 0, "flag");
$system_time = mysql_result($query, 0, "system_time");
$player1_name = mysql_result($query, 0, "player1_name");
$player2_name = mysql_result($query, 0, "player2_name");
$player3_name = mysql_result($query, 0, "player3_name");
$player1_status = mysql_result($query, 0, "player1_status");
$player2_status = mysql_result($query, 0, "player2_status");
$player3_status = mysql_result($query, 0, "player3_status");
$player1_p = mysql_result($query, 0, "player1_p");
$player2_p = mysql_result($query, 0, "player2_p");
$player3_p = mysql_result($query, 0, "player3_p");
$lord_p = mysql_result($query, 0, "lord_p");
$player1_time = mysql_result($query, 0, "player1_time");
$player2_time = mysql_result($query, 0, "player2_time");
$player3_time = mysql_result($query, 0, "player3_time");
$player1_show = mysql_result($query, 0, "player1_show");
$player2_show = mysql_result($query, 0, "player2_show");
$player3_show = mysql_result($query, 0, "player3_show");
$player1_score = mysql_result($query, 0, "player1_score");
$player2_score = mysql_result($query, 0, "player2_score");
$player3_score = mysql_result($query, 0, "player3_score");
$player1_tuoguan = mysql_result($query, 0, "player1_tuoguan");
$player2_tuoguan = mysql_result($query, 0, "player2_tuoguan");
$player3_tuoguan = mysql_result($query, 0, "player3_tuoguan");
$beishu = mysql_result($query, 0, "beishu");
cleanTable($_GET[tableID]);

if($player1_p == "" || $player2_p == "" || $player3_p == "" || $lord_p == "")
{
	if($lord_p){
		if($player1_p == '' && $player2_p != '' && $player3_p != '')
		{
			if($player1_name == $lord)
			mysql_query("update `tables` set `player1_score` = '".($player1_score + 2 * $beishu)."',`player2_score` = '".($player2_score - 1 * $beishu)."',`player3_score` = '".($player3_score - 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
			elseif($player2_name == $lord)
			mysql_query("update `tables` set `player2_score` = '".($player2_score - 2 * $beishu)."',`player1_score` = '".($player1_score + 1 * $beishu)."',`player3_score` = '".($player3_score + 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
			elseif($player3_name == $lord)
			mysql_query("update `tables` set `player3_score` = '".($player3_score - 2 * $beishu)."',`player1_score` = '".($player1_score + 1 * $beishu)."',`player2_score` = '".($player2_score + 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
		}
		if($player2_p == '' && $player1_p != '' && $player3_p != '')
		{
			if($player1_name == $lord)
			mysql_query("update `tables` set `player1_score` = '".($player1_score - 2 * $beishu)."',`player2_score` = '".($player2_score + 1 * $beishu)."',`player3_score` = '".($player3_score + 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
			elseif($player2_name == $lord)
			mysql_query("update `tables` set `player2_score` = '".($player2_score + 2 * $beishu)."',`player1_score` = '".($player1_score - 1 * $beishu)."',`player3_score` = '".($player3_score - 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
			elseif($player3_name == $lord)
			mysql_query("update `tables` set `player3_score` = '".($player3_score - 2 * $beishu)."',`player1_score` = '".($player1_score + 1 * $beishu)."',`player2_score` = '".($player2_score + 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
		}
		if($player3_p == '' && $player1_p != '' && $player2_p != '')
		{
			if($player1_name == $lord)
			mysql_query("update `tables` set `player1_score` = '".($player1_score - 2 * $beishu)."',`player2_score` = '".($player2_score + 1 * $beishu)."',`player3_score` = '".($player3_score + 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
			elseif($player2_name == $lord)
			mysql_query("update `tables` set `player2_score` = '".($player2_score - 2 * $beishu)."',`player1_score` = '".($player1_score + 1 * $beishu)."',`player3_score` = '".($player3_score + 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
			elseif($player3_name == $lord)
			mysql_query("update `tables` set `player3_score` = '".($player3_score + 2 * $beishu)."',`player1_score` = '".($player1_score - 1 * $beishu)."',`player2_score` = '".($player2_score - 1 * $beishu)."',`lord_p` = '' where `ID` = '".$_GET[tableID]."'");
		}
	}
	if($player1_status == "ready" && $player2_status == "ready" && $player3_status == "ready"){
		if($player1_name == $username)
		{
			$get_p = get_p();
			for($player1_p = "", $i = 0;$i < 17;$i ++)
			$player1_p .= $get_p[$i]."|";
			for($player2_p = "", $i = 17;$i < 34;$i ++)
			$player2_p .= $get_p[$i]."|";
			for($player3_p = "", $i = 34;$i < 51;$i ++)
			$player3_p .= $get_p[$i]."|";
			for($lord_p = "", $i = 51;$i < 54;$i ++)
			$lord_p .= $get_p[$i]."|";
			$player1_p = renew($player1_p);
			$player2_p = renew($player2_p);
			$player3_p = renew($player3_p);
			$lord_p = renew($lord_p);
			mysql_query("update `tables` set `player1_p` ='$player1_p',`player2_p` ='$player2_p',`player3_p` ='$player3_p',`lord_p` ='$lord_p' where `ID` = '".$_GET[tableID]."'");
		}
	}
}

if($username == $player1_name)
{
	mysql_query("update `tables` set `player1_name` ='$username',`player1_time` ='$oritime',`system_time` ='$oritime' where `ID` = '".$_GET[tableID]."'");
	$self_p = $player1_p;
}
if($username == $player2_name)
{
	mysql_query("update `tables` set `player2_name` ='$username',`player2_time` ='$oritime',`system_time` ='$oritime' where `ID` = '".$_GET[tableID]."'");
	$self_p = $player2_p;
}
if($username == $player3_name)
{
	mysql_query("update `tables` set `player3_name` ='$username',`player3_time` ='$oritime',`system_time` ='$oritime' where `ID` = '".$_GET[tableID]."'");
	$self_p = $player3_p;
}
echo $self_p.",".$lord.",".$lord_p.",".$flag.",".$beishu.",;".$username.",".$player1_name.",".$player2_name.",".$player3_name.",".$player1_status.",".$player2_status.",".$player3_status.",".$player1_show.",".$player2_show.",".$player3_show.",".countP($player1_p).",".countP($player2_p).",".countP($player3_p).",".$player1_score.",".$player2_score.",".$player3_score.",".$player1_tuoguan.",".$player2_tuoguan.",".$player3_tuoguan.",";
?>