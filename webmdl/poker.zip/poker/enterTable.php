<?php
include "./dbconnect.php";
$query = mysql_query("select * from `tables` where `ID` = '".$_GET[tableID]."'");
$num = mysql_num_rows($query);
if($num){
	$player1_name = mysql_result($query, 0, "player1_name");
	$player2_name = mysql_result($query, 0, "player2_name");
	$player3_name = mysql_result($query, 0, "player3_name");
	if($player1_name == $username || $player2_name == $username || $player3_name == $username)
	echo "success";
	elseif($player1_name != $username && $player2_name != $username && $player3_name != $username && $player1_name != "" && $player2_name != "" && $player3_name != "")
	echo "failure";
	else{
		if($player1_name == "")
		mysql_query("update `tables` set `player1_name` = '$username',`player1_time` = '$oritime',`system_time` = '$oritime' where `ID` = '".$_GET[tableID]."'");
		elseif($player2_name == "")
		mysql_query("update `tables` set `player2_name` = '$username',`player2_time` = '$oritime',`system_time` = '$oritime' where `ID` = '".$_GET[tableID]."'");
		elseif($player3_name == "")
		mysql_query("update `tables` set `player3_name` = '$username',`player3_time` = '$oritime',`system_time` = '$oritime' where `ID` = '".$_GET[tableID]."'");
	}
}
?>