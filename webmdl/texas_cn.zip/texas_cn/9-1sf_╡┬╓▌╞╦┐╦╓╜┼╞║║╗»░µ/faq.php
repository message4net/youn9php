<? 
require('includes/gen_inc.php'); 
?>
<html>
<head>
<title><? echo TITLE; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="css/poker.css" type="text/css">
<script language="JavaScript" type="text/JavaScript" src="js/lobby.php"></script></head>

<body bgcolor="#000000" text="#CCCCCC" >
<table width="772" border="0" cellspacing="0" cellpadding="2" align="center" bgcolor="#1B1B1B">
  <tr> 
    <td valign="top" bgcolor="#333333"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="1">
        <tr> 
          <td> 
            <? require('includes/scores.php'); ?>
          </td>
        </tr>
        <tr> 
          <td> 
            <table border="0" cellspacing="0" cellpadding="1" width="98%" class="smllfontpink" align="center" height="55">
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('index.php')" class="hand"> 
                <td> 
                  <? echo MENU_HOME; ?>
                </td>
              </tr>
              <? if (($valid == false) && (MEMMOD == 0)){ ?>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('login.php')" class="hand"> 
                <td> 
                  <? echo MENU_LOGIN; ?>
                </td>
              </tr>
              <? } ?>
              <? if ($valid == false){ ?>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('create.php')" class="hand"> 
                <td> 
                  <? echo MENU_CREATE; ?>
                </td>
              </tr>
              <? } ?>
              <? if ($valid == true){ ?>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('lobby.php')" class="hand"> 
                <td> 
                  <? echo MENU_LOBBY; ?>
                </td>
              </tr>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('rankings.php')" class="hand"> 
                <td> 
                  <? echo MENU_RANKINGS; ?>
                </td>
              </tr>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('myplayer.php')" class="hand"> 
                <td> 
                  <? echo MENU_MYPLAYER; ?>
                </td>
              </tr>
              <? } ?>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('rules.php')" class="hand"> 
                <td> 
                  <? echo MENU_RULES; ?>
                </td>
              </tr>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('faq.php')" class="hand"> 
                <td> 
                  <? echo MENU_FAQ; ?>
                </td>
              </tr>
              <? if ($ADMIN == true){ ?>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('admin.php')" class="hand"> 
                <td> 
                  <? echo MENU_ADMIN; ?>
                </td>
              </tr>
              <? } ?>
              <? if (($valid == true) && (MEMMOD != 1)){ ?>
              <tr onMouseOver="this.bgColor = '#330000'; this.style.color = 'FFFFFF'" onMouseOut="this.bgColor = ''; this.style.color = 'CC9999'" onClick="changeview('index.php?action=logout')" class="hand"> 
                <td>
                  <? echo MENU_LOGOUT; ?>
                </td>
                <? } ?>
            </table>
          </td>
        </tr>
      </table>
    </td>
    <td width="650" class="fieldsethead" valign="top" height="100%"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="3">
        <tr> 
          <td bgcolor="#333333"><b><font size="3"><i><? echo FAQ; ?></i></font></b> 
          </td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="4">
        <tr> 
          <td class="smllfontwhite" colspan="2"><b><font color="#FFCC33">&#22914;&#20309;<b>&#20462;&#25913;&#25105;&#30340;&#22836;&#35937;</b>?</font></b></td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2">&#22312;&#20027;&#35201;&#30340;&#22823;&#21381;&#33639;&#23631;&#20013;&#28857;&#20987;&#37027;&#32534;&#36753;&#20010;&#24615;&#32852;&#32534;&#21040;&#21464;&#21270;&#20320;&#30340;<b><font color="#FFCC33"><b>&#22836;&#35937;</b></font></b>&#25110;&#19978;&#20256;&#19968;&#20064;&#24815;<strong><font color="#FFCC33">&#22836;&#35937;</font></strong>&#12290; &#20064;&#24815;<b><font color="#FFCC33"><b>&#22836;&#35937;</b></font></b>&#19968;&#23450;&#20197; jpg &#22270;&#20687;&#26684;&#24335;&#21644;&#23569;&#20110; 250 kb &#22312;&#22823;&#23567;&#12290;</td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2"><b><font color="#FFCC33">&#20160;&#20040;&#26159;&#21160;&#20316;&#23450;&#26102;&#22120;?</font></b></td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2">&#37027;&#21160;&#20316;&#23450;&#26102;&#22120;&#30830;&#23450;&#24179;&#28369;&#30340;&#26700;&#23376;&#28216;&#25103;&#26681;&#25454;&#27773;&#36710;&#32487;&#32493;&#25240;&#21472;&#30340;&#25110;&#32773;&#34892;&#20026;&#25163;&#22914;&#26524;&#19968;&#20010;&#36816;&#21160;&#21592;&#20570;&#19981;&#22312;&#26399;&#38480;&#37324;&#38754;&#20381;&#29031;&#39034;&#24207;&#26159;&#32452;&#34987;&#37027;&#20301;&#32622;&#31649;&#29702;&#20154;&#12290; &#22914;&#26524;&#19968;&#20010;&#36816;&#21160;&#21592;&#37325;&#22797;&#22320;&#19981;&#21450;&#26684;&#20381;&#29031;&#39034;&#24207;&#20182;&#20204;&#24847;&#24535;&#26159;&#36386;&#36208;&#24320;&#37027;&#26700;&#23376;&#21644;&#20219;&#20309;&#30340;&#38065;&#24038;&#36793;&#22312;&#20182;&#20204;&#30340;&#22774;&#24847;&#24535;&#26159;&#38468;&#21152;&#30340;&#21521;&#21518;&#22320;&#22312;&#21040;&#20182;&#20204;&#30340;&#20043;&#19978;&#24635;&#25968;&#36164;&#37329;&#12290;</td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2">&#20026;&#20160;&#20040;&#20570;&#25105;&#25343;&#20174;&#19968;&#22330;&#28216;&#25103;&#36386;?</td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2">&#36816;&#21160;&#21592;&#33258;&#21160;&#22320;&#36386;&#22914;&#26524;&#20182;&#20204; repeadedly &#19981;&#21450;&#26684;&#20381;&#29031;&#39034;&#24207;&#21644;&#28216;&#25103;&#26377;&#23545;&#27773;&#36710;&#21160;&#20316;&#20182;&#20204;&#25110;&#22914;&#26524;&#20182;&#20204;&#22833;&#21435;&#26469;&#33258;&#26700;&#23376;&#30340;&#36830;&#25509;&#20026;&#36739;&#22810;&#30340;&#36229;&#36807;&#37027;&#20801;&#35768;&#26102;&#38388;&#12290; &#26102;&#38388;&#30340;&#38271;&#24230;&#26159;&#21464;&#25968;&#24403;&#20182;&#20204;&#26159;&#32452;&#34987;&#37027;&#20301;&#32622;&#31649;&#29702;&#20154;&#12290;<br></td>
        </tr>
        <tr>
          <td class="smllfontwhite" colspan="2"><b><font color="#FFCC33">&#25105;&#30340;&#36816;&#21160;&#21592;&#26159;&#19968;&#25991;&#19981;&#21517;&#30340;, &#20160;&#20040;&#29616;&#22312;?</font></b></td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2">&#22914;&#26524;&#37027;&#20301;&#32622;&#31649;&#29702;&#20154;&#26377;&#20351;&#36873;&#39033;&#33021;&#22815;, &#20320;&#33021;&#26356;&#26032;&#20320;&#30340;&#36215;&#22987;&#28216;&#25103;&#20449;&#29992;&#34249;&#30001;&#25353;&#37027;&#22312;&#20320;&#30340; &quot; &#25105;&#30340;&#36816;&#21160;&#21592; &quot; &#19978;&#26356;&#26032;&#38062;&#25187;&#39029;&#12290;</td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2"><b><font color="#FFCC33">&#25105;&#33021;&#22914;&#20309;&#24471;&#21040; PHP &#25169;&#20811;&#29260;&#30340;&#25105;&#33258;&#24049;&#30340;&#21103;&#26412;?</font></b></td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2"> 
            <p>PHP &#25169;&#20811;&#29260;&#33021;&#22312;&#20108;&#20010;&#26041;&#27861;&#20013;&#34987;&#36141;&#20080;&#12290; &#20320;&#33021;&#31199;&#37329;&#20320;&#33258;&#24049;&#30340;&#25169;&#20811;&#29260;&#26700;&#23376;&#20026;&#19968;&#20010;&#23567;&#30340;&#24180;&#36153;&#25110;&#36141;&#20080;&#37027;&#20840;&#37096;&#21253;&#35065;&#21040;&#23433;&#35013;&#22312;&#20320;&#33258;&#24049;&#30340;&#32593;&#31449;&#19978;&#12290; &#22240;&#20026;&#20851;&#20110; PHP &#25169;&#20811;&#29260;&#30340;&#36164;&#35759;,&#35831;&#25308;&#35775;&#25105;&#20204;&#30340;&#32593;&#31449;&#12290;<br>
              http://www.phppoker.net<br>
          </p>          </td>
        </tr>
        <tr> 
          <td class="smllfontwhite" colspan="2">&nbsp;</td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
