<?
// All Page Headings
//-----------------------------------------------------------
  define('HOME', '&#27426;&#36814;&#21040;'.TITLE);
  define('LOGIN', '&#24320;&#22987;&#28216;&#25103;');
  define('CREATE', '&#24080;&#21495;&#27880;&#20876;');
  define('LOBBY', '&#28216;&#25103;&#22823;&#21381;');
  define('RANKINGS', '&#29609;&#23478;&#25490;&#21517;');
  define('MY_PLAYER', '&#25105;&#30340;&#36164;&#26009;');
  define('RULES', '&#25169;&#20811;&#29260;&#35268;&#21017;');
  define('FAQ', '&#24120;&#35265;&#30097;&#38382;');
  define('ADMIN', '&#31649;&#29702;');
  define('LOGOUT', '&#35760;&#24405;&#22806;&#38754;&#30340;');
  define('SITOUT', '&#36864;&#20986;');

// Main Menu
//-----------------------------------------------------------
  define('MENU_HOME', '&#20027;&#39029');
  define('MENU_LOGIN', '&#24320;&#22987;&#28216;&#25103;');
  define('MENU_CREATE', '&#24080;&#21495;&#27880;&#20876;');
  define('MENU_LOBBY', '&#28216;&#25103;&#22823;&#21381;');
  define('MENU_RANKINGS', '&#29609;&#23478;&#25490;&#21517;');
  define('MENU_MYPLAYER', '&#25105;&#30340;&#36164;&#26009;');
  define('MENU_RULES', '&#25169;&#20811;&#29260;&#35268;&#21017;');
  define('MENU_FAQ', '&#24120;&#35265;&#30097;&#38382;');
  define('MENU_ADMIN', '&#31649;&#29702;');
  define('MENU_LOGOUT', '&#35760;&#24405;&#22806;&#38754;&#30340;');

// Table Types & Poker Page
//-----------------------------------------------------------
  define('SITNGO', '&#20241;&#38386;&#31867;');
  define('TOURNAMENT', '&#24033;&#22238;&#36187;');
  define('DEALER_INFO', '&#32463;&#38144;&#21830;&#25968;&#25454;');
  define('TABLEPOT', '&#24635;&#38065;:');
  define('BUTTON_LEAVE', '&#22238;&#22823;&#21381;&#21435;');
  define('BUTTON_SEND', '&#21457;&#36865;&#20449;&#24687;');

// Top 6 players mod
//-----------------------------------------------------------
  define('PLACE_POSI_1', 'st');
  define('PLACE_POSI_2', 'nd');
  define('PLACE_POSI_3', 'rd');
  define('PLACE_POSI', 'th');
  define('PLACE', 'Place');

// Login Page
//-----------------------------------------------------------
  define('BOX_LOGIN', '&#24320;&#22987;&#28216;&#25103;');
  define('LOGIN_USER', '&#24080;&#21495;:');
  define('LOGIN_PWD', '&#23494;&#30721;&#65306;');
  define('BUTTON_LOGIN', '&#30331;&#24405;');
  define('LOGIN_NEW_PLAYER', '&#22312;&#36825;&#37324;&#30340;&#28857;&#20987;&#21019;&#36896;&#19968;&#20010;&#26032;&#30340;&#24080;&#21495;');
  define('LOGIN_MSG_APPROVAL', '&#24080;&#25143;&#27880;&#20876;&#22833;&#36133;');
  define('LOGIN_MSG_BANNED', '&#36825;&#20010;&#24080;&#25143;&#26377;&#26159;&#31105;&#27490;!');
  define('LOGIN_MSG_INVALID', '&#20154;&#29289;&#30331;&#24405;!');

// Sitout Page
//-----------------------------------------------------------
  define('SITOUT_TIMER', '&#20498;&#35745;&#26102;');

// Create Player Page
//-----------------------------------------------------------
  define('BOX_CREATE_NEW_PLAYER', '&#21019;&#36896;&#20320;&#30340;&#24080;&#21495;');
  define('BOX_CREATE_NEW_AVATAR', '&#36873;&#25321;&#20320;&#30340;&#22836;&#35937;');
  define('CREATE_PLAYER_NAME', '&#24080;&#21495;:');
  define('CREATE_PLAYER_PWD', '&#23494;&#30721;:');
  define('CREATE_PLAYER_CONFIRM', 'Confirm:');
  define('CREATE_PLAYER_EMAIL', '&#30830;&#35748;&#23494;&#30721;:');
  define('CREATE_PLAYER_CHAR_LIMIT', '[5-10&#20010;&#25968;&#23383;&#25110;&#23383;&#27597; ]');
  define('CREATE_MSG_IP_BANNED', '&#20320;&#30340; IP &#20303;&#22336;&#26159;&#31105;&#27490;!');
  define('CREATE_MSG_MISSING_DATA', '&#26381;&#21153;&#22120;&#24537;, &#35831;&#23581;&#35797;&#20877;&#12290;');
  define('CREATE_MSG_AUTHENTICATION_ERROR', '&#24080;&#21495;&#38169;&#35823;!');
  define('CREATE_MSG_ALREADY_CREATED', '&#24080;&#21495;&#23384;&#22312;&#20102;');
  define('CREATE_MSG_INVALID_EMAIL', '&#36825;&#20010;&#30005;&#23376;&#37038;&#20214;&#20303;&#22336;&#19981;&#26159;&#26377;&#25928;.');
  define('CREATE_MSG_USERNAME_TAKEN', '&#24050;&#32463;&#25343;&#30340;&#20351;&#29992;&#32773;&#21517;&#31216;&#12290; &#20877;&#35831;&#23581;&#35797;.');
  define('CREATE_MSG_USERNAME_MWCHECK', '&#20351;&#29992;&#32773;&#21517;&#31216;&#26377;&#22826;&#22810; m\'s &#25110; w\' s &#22312;&#23427;&#37324;&#38754;!');
  define('CREATE_MSG_USERNAME_CHARS', '&#20351;&#29992;&#32773;&#21517;&#31216;&#33021;&#21253;&#21547;&#20449;&#12289;&#25968;&#23383;&#21644;&#24213;&#32447;.');
  define('CREATE_MSG_USERNAME_LENGTH', 'Your username must be 5-10 characters long.');
  define('CREATE_MSG_PASSWORD_CHARS', 'Passwords can contain letters, numbers and underscores.');
  define('CREATE_MSG_PASSWORD_LENGTH', 'Your password must be 5-10 characters long.');
  define('CREATE_MSG_PASSWORD_CHECK', 'Your password and confirmation must match!');
  define('CREATE_MSG_CHOOSE_AVATAR', '&#35831;&#36873;&#25321;&#19968;&#20010;&#22836;&#35937;');
  define('CREATE_APPROVAL_EMAIL_CONTENT', 'Thank you for applying to join our poker game. Please click the link to activate your player:');
  define('CREATE_APPROVAL_EMAIL_ALERT', 'An activation email has been sent to the address you gave us.');
  define('BUTTON_SUBMIT', 'Submit');



// Game Lobby Page
//-----------------------------------------------------------
  define('TABLE_HEADING_NAME', '&#26700;&#23376;&#21517;&#23383;');
  define('TABLE_HEADING_PLAYERS', '&#20154;&#25968;');
  define('TABLE_HEADING_TYPE', '&#26700;&#23376;&#31867;&#22411;');
  define('TABLE_HEADING_BUYIN', '&#22823;/&#23567;&#30450;&#27880;');
  define('TABLE_HEADING_SMALL_BLINDS', '&#26368;&#23569;&#25658;&#24102;');
  define('TABLE_HEADING_BIG_BLINDS', '&#26368;&#22810;&#25658;&#24102;');
  define('TABLE_HEADING_STATUS', '&#26700;&#23376;&#29366;&#24577;');
  define('NEW_GAME', '&#26032;&#28216;&#25103;');
  define('PLAYING', '&#29609;');

// My Player & Player Rankings Pages
//-----------------------------------------------------------
  define('PLAYER_PROFILE', '&#24080;&#21495;');
  define('PLAYER_IS_BROKE', '&#23567;&#29482;&#29482;&#20320;&#26159;&#20010;&#27809;&#21517;&#27668;&#30340;&#20154;!!');
  define('PLAYER_STATS', '&#32479;&#35745;&#34920;:');
  define('PLAYER_CHOOSE_AVATAR', '&#26356;&#25442;&#22836;&#35937;');
  define('PLAYER_CHANGE_PWD', 'Change Password');
  define('BOX_GAME_STATS', '&#31572;&#26696;:');
  define('BOX_MOVE_STATS', '&#31649;&#29702;&#20154;');
  define('BOX_HAND_STATS', '&#36149;&#23486;&#24080;&#21495;');
  define('BOX_FOLD_STATS', '&#26399;&#38480; &amp;&#24773;&#20917;');
  define('BOX_STD_AVATARS', '&#31995;&#32479;&#33258;&#24102;&#22836;&#35937;');
  define('BOX_CUSTOM_AVATARS', '&#37117;&#19981;&#22909;&#30475;&#33258;&#24049;&#19978;&#20256;&#20010;');

  define('STATS_GAME', '&#28216;&#25103;&#32479;&#35745;');
  define('STATS_HAND', '&#25163;&#32479;&#35745;');
  define('STATS_MOVE', '&#21160;&#20316;&#32479;&#35745;');
  define('STATS_FOLD', '&#25240;&#23618;&#32479;&#35745;');
  define('STATS_PLAYER_NAME', '&#24080;&#21495;&#65306;');
  define('STATS_PLAYER_RANKING', '&#25490;&#21517;:');
  define('STATS_PLAYER_CREATED', '&#24080;&#25143;&#21019;&#36896;&#26102;&#38388;:');
  define('STATS_PLAYER_BANKROLL', '&#36164;&#37329;:');
  define('STATS_PLAYER_LOGIN', '&#26368;&#21518;&#30331;&#24405;&#26102;&#38388;:');
  define('STATS_PLAYER_GAMES_PLAYED', '&#28216;&#25103;&#29609;&#36807;&#27425;&#25968;:');
  define('STATS_PLAYER_TOURNAMENTS_PLAYED', '&#24033;&#22238;&#36187;&#29609;:');
  define('STATS_PLAYER_TOURNAMENTS_WON', '&#24033;&#22238;&#36187;&#38889;&#24065;');
  define('STATS_PLAYER_TOURNAMENTS_RATIO', '&#24033;&#22238;&#36187;&#36194;&#27604;');
  define('STATS_PLAYER_HANDS_PLAYED', '&#29609;:');
  define('STATS_PLAYER_HANDS_WON', '&#38889;&#24065;:');
  define('STATS_PLAYER_HAND_RATIO', '&#36194;&#27604;:');
  define('STATS_PLAYER_FOLD_RATIO', '&#25240;&#23618;&#27604;:');
  define('STATS_PLAYER_CHECK_RATIO', '&#26816;&#26597;&#27604;:');
  define('STATS_PLAYER_CALL_RATIO', '&#21628;&#21483;&#27604;:');
  define('STATS_PLAYER_RAISE_RATIO', '&#19978;&#21319;&#27604;:');
  define('STATS_PLAYER_ALLIN_RATIO', '&#25152;&#26377;&#30340;&#22312;&#27604;:');
  define('STATS_PLAYER_FOLD_PREFLOP', '&#25240;&#23618;&#21069;&#30768;&#28982;&#33853;&#19979;:');
  define('STATS_PLAYER_FOLD_FLOP', '&#25240;&#23618;&#22312;&#30768;&#28982;&#33853;&#19979;&#20043;&#21518;');
  define('STATS_PLAYER_FOLD_TURN', '&#25240;&#23618;&#22312;&#26059;&#36716;&#20043;&#21518;:');
  define('STATS_PLAYER_FOLD_RIVER', '&#25240;&#23618;&#22312;&#27827;&#20043;&#21518;:');
  define('STATS_PLAYER_OLD_PWD', '&#26087;&#30340;&#23494;&#30721;:');
  define('STATS_PLAYER_NEW_PWD', '&#26032;&#30340;&#23494;&#30721;:');
  define('STATS_PLAYER_CONFIRM_PWD', '&#30830;&#35748;&#23494;&#30721;:');
  define('STATS_PLAYER_PWD_CHAR_LIMIT', '[5-10&#20010;&#25968;&#23383;&#25110;&#23383;&#27597;]');
  define('BUTTON_STATS_PLAYER_CREDIT', '&#28857;&#20987;&#22312;&#36825;&#37324;&#26356;&#26032;&#20320;&#30340;&#36215;&#22987;&#20449;&#24687;');
  define('BUTTON_UPLOAD', '&#19978;&#20256;');

  define('STATS_MSG_FILE_FORMAT', '&#20320;&#30340;&#22270;&#20687;&#19968;&#23450;&#20197; jpg &#30340;&#26684;&#24335;!');
  define('STATS_MSG_FILE_FORMAT', '&#20320;&#30340;&#22270;&#20687;&#19968;&#23450;&#26159;&#23569;&#20110; 300 kb!');
  define('STATS_MSG_MISSING_DATA', 'Your image must be in jpg format!');
  define('STATS_MSG_PWD_CHARS', 'Passwords can only contain letters and numbers.');
  define('STATS_MSG_PWD_LENGTH', 'Your password must be 5-10 chars long.');
  define('STATS_MSG_PWD_CONFIRM', 'Your new password and confirm fields must match.');
  define('STATS_MSG_PWD_INCORRECT', '&#20320;&#30340;&#26087;&#23494;&#30721;&#26159;&#19981;&#27491;&#30830;&#30340;!');

// Admin Panel
//-----------------------------------------------------------
  define('ADMIN_MANAGE_TABLES', '.&#22788;&#29702;&#26700;&#23376;');
  define('ADMIN_MANAGE_MEMBERS', '&#22788;&#29702;&#25104;&#21592;');
  define('ADMIN_MANAGE_SETTINGS', '&#35774;&#23450;');
  define('ADMIN_MANAGE_STYLES', '&#39118;&#26684;');
  define('ADMIN_SETTINGS_UPDATED', '&#20320;&#30340;&#28216;&#25103;&#35774;&#23450;&#26377;&#26159;&#26356;&#26032;!');

  define('ADMIN_GENERAL', '&#19968;&#33324;&#30340;&#35774;&#23450;');
  define('ADMIN_SETTINGS_TITLE', 'Browser Page Title:');
  define('ADMIN_SETTINGS_EMAIL', 'Require Email Address:');
  define('ADMIN_SETTINGS_APPROVAL', 'Approval Mode:');
  define('ADMIN_SETTINGS_IPCHECK', 'IP Check:');
  define('ADMIN_SETTINGS_LOGIN', 'Bypass Login:');
  define('ADMIN_SETTINGS_SESSNAME', 'Session Name:');
  define('ADMIN_SETTINGS_AUTODELETE', 'Auto Delete Players:');
  define('ADMIN_SETTINGS_STAKESIZE', 'Server Stake Size:');
  define('ADMIN_SETTINGS_BROKE_BUTTON', '"Your Broke" Button:');
  define('ADMIN_TIMER', 'Timer Settings');
  define('ADMIN_SETTINGS_KICK', 'Kick Timer:');
  define('ADMIN_SETTINGS_MOVE', 'Move Timer:');
  define('ADMIN_SETTINGS_SHOWDOWN', 'Showdown Timer:');
  define('ADMIN_SETTINGS_SITOUT', 'Sit Out Timer:');
  define('ADMIN_SETTINGS_DISCONNECT', 'Disconnect Timer:');
  define('ADMIN_SETTINGS_TITLE_HELP', 'This title will appear in your web browsers page title.');
  define('ADMIN_SETTINGS_EMAIL_HELP', 'Select if members need to provide an email address when signing up.');
  define('ADMIN_SETTINGS_APPROVAL_HELP', 'Select automatic, email verification or admin approval.');
  define('ADMIN_SETTINGS_IPCHECK_HELP', 'Prevent multiple players with identical IP addesses playing at the same table.');
  define('ADMIN_SETTINGS_LOGIN_HELP', 'Switch this on if you are using your own session based login system.');
  define('ADMIN_SETTINGS_SESSNAME_HELP', 'Your identifying session name from your own login system.');
  define('ADMIN_SETTINGS_AUTODELETE_HELP', 'Select if you want the system to delete inactive players.');
  define('ADMIN_SETTINGS_STAKESIZE_HELP', 'Switch the server stakes size from tiny stakes to high rollers .');
  define('ADMIN_SETTINGS_BROKE_BUTTON_HELP', '"Turn on/off "Your Broke" module and initial free game stake.');
  define('ADMIN_SETTINGS_KICK_HELP', 'Controls kicking players repeatedly failing to take their turn.');
  define('ADMIN_SETTINGS_MOVE_HELP', 'Controls the time a player has to make their move.');
  define('ADMIN_SETTINGS_SHOWDOWN_HELP', 'Controls the time a showdown hand will be displayed for.');
  define('ADMIN_SETTINGS_SITOUT_HELP', 'Controls the length of stay on the sit out page.');
  define('ADMIN_SETTINGS_DISCONNECT_HELP', 'Controls the time before kicking disconnected players.');
  define('BUTTON_SAVE_SETTINGS', 'Save Settings');

  define('ADMIN_MEMBERS_NAME', 'Player Name');
  define('ADMIN_MEMBERS_RANK', 'Rank');
  define('ADMIN_MEMBERS_EMAIL', 'Email');
  define('ADMIN_MEMBERS_CREATED', 'Created');
  define('ADMIN_MEMBERS_IPADDRESS', 'IP Address');
  define('ADMIN_MEMBERS_APPROVE', 'Approve');
  define('ADMIN_MEMBERS_BAN', 'Ban');
  define('ADMIN_MEMBERS_DELETE', 'Delete');
  define('ADMIN_MEMBERS_RESET_STATS', 'Stats');
  define('BUTTON_APPROVE', 'Approve');
  define('BUTTON_BAN', 'Ban');
  define('BUTTON_UNBAN', 'Unban');
  define('BUTTON_DELETE', 'Delete');
  define('BUTTON_RESET', 'Reset');
  define('BUTTON_CREATE_TABLE', 'Create Table');
  define('BUTTON_INSTALL', 'Install');

  define('ADMIN_TABLES_NAME', 'Table Name');
  define('ADMIN_TABLES_TYPE', 'Table Type');
  define('ADMIN_TABLES_MIN', 'Minimum Buyin');
  define('ADMIN_TABLES_MAX', 'Maximum Buyin');
  define('ADMIN_TABLES_STYLE', 'Table Style');
  define('ADMIN_TABLES_DELETE', 'Delete');

  define('ADMIN_STYLES_INSTALLED', 'Installed Table Styles');
  define('ADMIN_STYLES_PREVIEW', 'Style Preview');
  define('ADMIN_STYLES_NEW_NAME', 'New Style Name');
  define('ADMIN_STYLES_CODE', 'Validation Code');

   define('ADMIN_MSG_STYLE_INSTALLED', 'This style has already been installed!');
   define('ADMIN_MSG_MISSING_DATA', 'Missing data! Please try again.');
   define('ADMIN_MSG_INVALID_CODE', 'Invalid style name or license code!');

// Poker Game Language
//-----------------------------------------------------------
  define('GAME_LOADING', '&#36733;&#20837;...');
  define('GAME_PLAYER_BUYS_IN', '&#22823;/&#23567;&#30450;&#27880;');
  define('INSUFFICIENT_BANKROLL_SITNGO', '&#20808;&#29983;&#22899;&#22763;&#20320;&#30340;&#38065;&#19981;&#36275;&#22815;&#21040;&#28216;&#25103;&#22312;&#36825;&#20043;&#19978;&#26700;&#23376;��');
  define('INSUFFICIENT_BANKROLL_TOURNAMENT', '&#20808;&#29983;&#22899;&#22763;&#20320;&#30340;&#38065;&#19981;&#36275;&#22815;&#21040;&#28216;&#25103;&#22312;&#36825;&#20043;&#19978;&#26700;&#23376;!');
  define('GAME_STARTING', '&#28216;&#25103;&#20986;&#21457;...');
  define('GAME_PLAYER_FOLDS', '&#25240;&#23618;');
  define('GAME_PLAYER_CALLS', '&#21628;&#21483;');
  define('GAME_PLAYER_CHECKS', '&#26816;&#26597;');
  define('GAME_PLAYER_RAISES', '&#19978;&#21319;');
  define('GAME_PLAYER_GOES_ALLIN', '&#21464;&#25152;&#26377;&#22312;');
  define('GAME_PLAYER_POT', 'POT:');

  define('GAME_MSG_WON_TOURNAMENT', 'won the last tournament');
  define('GAME_MSG_LOST_CONNECTION', '&#22833;&#21435;&#36830;&#25509;');
  define('GAME_MSG_PLAYER_BUSTED', '&#36827;&#20837;&#26412;&#26700;&#23376;');
  define('GAME_MSG_PLAYERS_JOINING', 'players joining...');
  define('GAME_MSG_LETS_GO', 'lets go!!');
  define('GAME_MSG_CHIP_LEADER', 'chip leader is');
  define('GAME_MSG_DEALER_BUTTON', 'has the dealer button');
  define('GAME_MSG_DEAL_CARDS', 'dealing the holecards...');
  define('GAME_MSG_DEAL_FLOP', 'dealing the flop...');
  define('GAME_MSG_DEAL_TURN', 'dealing the turn...');
  define('GAME_MSG_DEAL_RIVER', 'dealing the river...');
  define('GAME_MSG_SHOWDOWN', 'SHOWDOWN!');
  define('GAME_MSG_ALLFOLD', 'wins, everyone folded');
  define('GAME_MSG_PLAYER_ALLIN', 'is all in');
  define('GAME_MSG_DEAL_RIVER', 'dealing the river...');
  define('GAME_MSG_SMALL_BLIND', 'posts small blind');
  define('GAME_MSG_BIG_BLIND', 'posts big blind');
  define('GAME_MSG_SPLIT_POT', 'split pot');
  define('GAME_MSG_SPLIT_POT_RESULT', 'The pot is split between the players who have the best');
  define('GAME_MSG_WINNING_HAND', '&#32988;&#21033;&#25163;:');
  define('GAME_MSG_PROCESSING', '&#22788;&#29702;...');

  define('BUTTON_START', '&#24320;&#22987;&#28216;&#25103;');
  define('BUTTON_CALL', '&#21628;&#21483;');
  define('BUTTON_CHECK', '&#26816;&#26597;');
  define('BUTTON_FOLD', '&#25240;&#23618;');
  define('BUTTON_BET', '&#25171;&#36172;');
  define('BUTTON_ALLIN', '&#25152;&#26377;&#30340;&#22312;');

  define('WIN_PAIR', 'pair of'); // e.g. user wins with a pair of 9's
  define('WIN_2PAIR', '2 pair'); // e.g. user wins 2 pair 3's & 8's
  define('WIN_FULLHOUSE', 'full house'); // e.g. user wins with a full house
  define('WIN_SETOF3', 'a set of');  // e.g. user wins with a set of 3's
  define('WIN_SETOF4', 'all the'); // e.g. user wins with all the J's
  define('WIN_FLUSH', 'high flush'); // e.g. user wins with a K high flush
  define('WIN_STRAIGHT_FLUSH', 'straight flush'); // e.g. user wins with a K high straight flush
  define('WIN_ROYALFLUSH', 'royal flush'); // e.g. user wins with a royal flush
  define('WIN_STRAIGHT', 'high straight'); // e.g. user wins with a J high straight
define('WIN_LOW_STRAIGHT', 'low straight'); // e.g. user wins with a low straight
define('WIN_HIGHCARD', 'highcard'); // e.g. user wins with a k highcard

?>