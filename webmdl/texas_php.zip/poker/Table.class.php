<?php
include "Cards.class.php";
include "Player.class.php";

class  Table{

    public $players=array();
    public $tablecards=array();

    function __construct($num,$cards)
    {
        for($i=0;$i<$num;$i++){
            $this->players[$i]=new Player($cards);
            $cards=array_diff($cards,$this->players[$i]->CardInHand);
            //print_r($cards);exit;
            $k=$i+1;
            echo "玩家".$k."的手牌为<br>";
            $this->showCard($this->players[$i]->CardInHand);
            echo "<br>==========<br>";
        }
        array_shift($cards);
        for($i=0;$i<3;$i++) {
            $this->tablecards[] = $cards[$i];
        }
        $cards=array_diff($cards,$this->tablecards);
        for($i=0;$i<2;$i++){
            array_shift($cards);
            $this->tablecards[] = $cards[0];
        }
        echo "<br>====公牌为====<br>";
        $this->showCard($this->tablecards);

        for($i=0;$i<count($this->players);$i++){
            $k=$i+1;
            echo "<br>----玩家{$k}的结果为----<br>";
            $this->result($this->players[$i]);
            echo "<br>-----------------------<br>";
        }
    }

    private function showCard($cards){
        $path = "";
        foreach ($cards as $ca) {
            //print_r($ca);exit;
            $path.= "<img src='./pukeImage/". $ca . ".jpg'>";
        }
        echo $path;
    }

    private function pre($str,$comment){
        echo "<pre>=={$comment}===<br>";
        print_r($str);
        echo '</pre>====<br>';
    }

    private function result(Player $p){

        $suit = "";
        $point = "";
        $p->CardInHand = array(0 => 'S4',1 => 'SK');
        $this->tablecards = array(0 => 'S5',1 => 'S6', 2 => 'S7', 3 => 'S8', 4 => 'S9');
        $result=array_merge($p->CardInHand,$this->tablecards);
        foreach($result as $c){
            $suit.=$c[0];
            $point.=$c[1];
        }
        //字符串转换为数组
        //花色
        $su=str_split($suit);
        //点数
        $po=str_split($point);
        //统计花色和点数
        $su_count=array_count_values($su);
        $po_count=array_count_values($po);
        /*switch(max($su_count)){
            case "5":
                echo "这是".array_keys($su_count,"5")[0]."同花"."<br>";
                $this->showCard($this->pukesort($result));
                break;
            default:
                switch(max($po_count)){
                    case "4":
                        echo "这是".array_keys($po_count,"4")[0]."四条"."<br>";
                        $this->isStraight($result);
                        break;
                    case "3":
                        echo "这是".array_keys($po_count,"3")[0]."三条"."<br>";
                        $this->isStraight($result);
                        break;
                    case "2":
                        echo "这是".array_keys($po_count,"2")[0]."对子"."<br>";
                        $this->isStraight($result);
                        break;
                    default:
                        $this->isStraight($result);

                }
                break;
        }*/
        if(max($su_count) >= 5){
            $aa = $this->isStraight($result);
            print_r($aa);exit;
        }
    }

    private function pukesort($cards){
        foreach($cards as $ca){
            $arr[]=$ca[1];
        }
        $arr=array_count_values($arr);


        foreach(array_keys($arr) as $v) {
            switch ($v) {
                case "A":
                    $poi[] = 14;
                    break;
                case "K":
                    $poi[] = 13;
                    break;
                case "Q":
                    $poi[] = 12;
                    break;
                case "J":
                    $poi[] = 11;
                    break;
                case "T":
                    $poi[] = 10;
                    break;
                default:
                    $poi[] = $v;
                    break;
            }
        }

        $puke=array(
            "num"=>array_values($arr),
            "poi"=>$poi
        );

        array_multisort($puke["num"], SORT_NUMERIC, SORT_DESC,
            $puke["poi"],SORT_NUMERIC, SORT_DESC
        );
        $arr= array_combine($puke["poi"],$puke["num"]);

        foreach($arr as $key=>$value){
            switch($key){
                case "14":
                    $arr1["A"]=$arr["14"];
                    break;
                case "13":
                    $arr1["K"]=$arr["13"];
                    break;
                case "12":
                    $arr1["Q"]=$arr["12"];
                    break;
                case "11":
                    $arr1["J"]=$arr["11"];
                    break;
                case "10":
                    $arr1["T"]=$arr["10"];
                    break;
                default:
                    $arr1[$key]=$value;
                    break;
            }
        }
        $keys=array_keys($arr1);
        foreach($keys as $v){
            $pstr= '/.'.$v.'/';
            foreach($cards as $c) {
                if(preg_match($pstr,$c)){
                    $maxcard[]=$c;
                }
            }
        }
        $maxcard=array_slice($maxcard,0,5);
        return $maxcard;
    }

    private function pointToNum($arr){
        $num=0;
        //统计在这副牌型中点数为数字的情况，从而判断A是做14合适还是作1合适
        foreach($arr as $p){
            if(!is_numeric($p))
                $num++;
        }
        foreach($arr as $p){
            switch($p){
                case "A":
                    if($num>=5){
                        $poi[]=14;
                    }else{
                        $poi[]=1;//A还可以作为1使用
                    }
                    break;
                case "K":
                    $poi[]=13;
                    break;
                case "Q":
                    $poi[]=12;
                    break;
                case "J":
                    $poi[]=11;
                    break;
                case "T":
                    $poi[]=10;
                    break;
                default:
                    $poi[]=$p;
                    break;
            }
        }
        return $poi;
    }

    private function numToPoint($arr){
        foreach($arr as $p){
            switch($p){
                case "14":
                case "1":
                    $poi[]="A";
                    break;
                case "13":
                    $poi[]="K";
                    break;
                case "12":
                    $poi[]="Q";
                    break;
                case "11":
                    $poi[]="J";
                    break;
                case "10":
                    $poi[]="T";
                    break;
                default :
                    $poi[]=$p;
            }
        }
        return $poi;
    }

    private function isStraight($cards){
        $point = "";
        foreach($cards as $c){
            $point.=$c[1];
        }
        $po=array_unique(str_split($point));
        //如果元素不为5个，则不满足顺子成牌的基本条件
        if(count($po)<5){
            $this->showCard($this->pukesort($cards));
        }else{
            $po=$this->pointToNum($po);
            arsort($po);
            $a1=array_values($po);
            $j=0;
            for($i=1;$i<count($a1);$i++){
                if($a1[$i]==$a1[$i-1]-1){
                    $j++;
                    $a2[]=array_search($a1[$i-1],$po);
                    $a2[]=array_search($a1[$i],$po);
                }else{
                    $j=0;
                }
            }
            if($j>=4){
                $a2=array_unique($a2);//去掉重复值
                $a2=array_values($a2);//重建索引
                $a2=array_slice($a2,0,5);//取出5个元素
                for($i=0;$i<count($a2);$i++){
                    $result[]=$po[$a2[$i]];
                }
                $arr=$this->numToPoint($result);
                foreach($arr as $v){
                    $pstr= '/.'.$v.'/';
                    foreach($cards as $c) {
                        if(preg_match($pstr,$c)){
                            $maxcard[]=$c;
                            break;
                        }
                    }
                }
                $this->showCard($this->pukesort($maxcard));
            }else{
                $this->showCard($this->pukesort($cards));
            }
        }
    }
}