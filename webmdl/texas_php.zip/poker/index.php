<?php
include "Table.class.php";
//显示函数
function pre($str){
    echo '<pre>';
    print_r($str);
    echo '</pre>';
}

//创建扑克牌
$c=new Cards();
//初始化玩家数量
$table=new Table(2,$c->Cards);