<?php
class Player{

    public $score=0;
    public $CardInHand=array();

    function __construct($cards)
    {
        $this->getCardInHand($cards);
    }

    private function getCardInHand($cards){
        $randkey=array_rand($cards,2);
        $this->CardInHand[]=$cards[$randkey[0]];
        $this->CardInHand[]=$cards[$randkey[1]];
        return $this->CardInHand;
    }

}