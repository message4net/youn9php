<?php
class Cards{
    public $Cards=array();

    function __construct()
    {
        $this->Cards=$this->createCards();
        shuffle($this->Cards);
    }
    private function createCards()
    {
        $cards=array();
        $suit=array("H","S","D","C");
        $p=array("T","J","Q","K","A");

        for($i=0;$i<count($suit);$i++){
            for($j=2;$j<=9;$j++){
                $cards[]=$suit[$i].$j;
            }
            for($k=0;$k<count($p);$k++){
                $cards[]=$suit[$i].$p[$k];
            }
        }
        return $cards;
    }
}